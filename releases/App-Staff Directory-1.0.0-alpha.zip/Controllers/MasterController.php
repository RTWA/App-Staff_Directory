<?php

namespace WebApps\Apps\StaffDirectory\Controllers;

use App\Http\Controllers\AppsController;

class MasterController extends AppsController
{
    //
}
